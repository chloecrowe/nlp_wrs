#!/usr/bin/env python
# coding: utf-8


# for hdbscan installation error, please use: conda install -c conda-forge hdbscan
# for hnswlib installation error: conda install -c conda-forge hnswlib

# !pip install top2vec
# pip install top2vec[sentence_encoders]
# pip install top2vec[sentence_transformers]
# pip install top2vec[indexing]




import numpy as np 
import pandas as pd
from top2vec import Top2Vec as tv
import os 
import glob
import shutil
import click

import random
random.seed(10)

os.getcwd()

import warnings
warnings.filterwarnings('ignore')


class top2vec_model:
    
    with open(r'data\\stopword_free.txt', encoding="utf8") as f:
        no_stops = f.readlines()

    model = tv(documents=no_stops, speed="learn", workers=2, ngram_vocab=True, hdbscan_args = {'min_cluster_size': 7} )
    num_tops = model.get_num_topics()
    num_tops

    model.generate_topic_wordcloud(0)

    topic_mapping = model.hierarchical_topic_reduction(num_topics=1)
    topic_sizes, topic_nums = model.get_topic_sizes()

    # get topics
    topic_words, word_scores, topic_nums = model.get_topics(num_tops)
    topic_words

    # search topics
    topic_words, word_scores, topic_scores, topic_nums = model.search_topics(keywords=["city"], num_topics=num_tops)


    # generate word cloud
    topic_words, word_scores, topic_scores, topic_nums = model.search_topics(keywords=["city"], num_topics=num_tops)
    for topic in topic_nums:
        model.generate_topic_wordcloud(topic, background_color='white', reduced=False)


    model.search_documents_by_topic(0, num_docs=1)

    model.search_documents_by_topic(1, num_docs=1)

    # search documents by topic:
    documents, document_scores, document_ids = model.search_documents_by_topic(topic_num=1, num_docs=3)

    model.get_topic_sizes(reduced=False)

    model.topic_words_reduced

    # semantic search documens by keywords
    documents, document_scores, document_ids = model.search_documents_by_keywords(keywords=["green"], num_docs=3)
    for doc, score, doc_id in zip(documents, document_scores, document_ids):
        print(f"Document: {doc_id}, Score: {score}")
        print("-----------")
        print(doc)
        print("-----------")
        print()


    # search for similar words to "green"
    words, word_scores = model.similar_words(keywords=["green"], keywords_neg=[], num_words=20)
    for word, score in zip(words, word_scores):
        print(f"{word} {score}")

