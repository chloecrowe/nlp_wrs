#!/usr/bin/env python
# coding: utf-8

from nltk.tokenize import sent_tokenize, word_tokenize
import numpy as np
import pandas as pd
import os
import glob
import shutil
from nltk.corpus import stopwords

os.getcwd()

class prepro:
    enviro = open(
        r'data/enviro.txt',
        encoding='utf-8')
    other = open(
        r'data/other.txt',
        encoding='utf-8')
    resourse = open(
        r'data/resources.txt',
        encoding='utf-8')
    trans = open(
        r'data/transport.txt',
        encoding='utf-8')
    urban = open(
        r'data/urban.txt',
        encoding='utf-8')

    # Replace the variable with what file you want.
    Lines = enviro.readlines()

    count = 0
    # Strips the newline character
    for line in Lines:
        count += 1
        print("{}".format(line.strip()))
        if count == 280:
            print("Topic 1 full qoute: ".format(line))

    print(Lines[246])

    print(count)  # 305 comments.

    with open(
            'data\\stopword_free.txt',
            'w', encoding='utf-8') as f:
        for line in Lines:
            tokens = word_tokenize(line.lower())
            # print("Tokens:", tokens)
            # Remove stop words
            #english_stopwords = stopwords.words('english')
            tokens_wo_stopwords = [t for t in tokens if t not in stopwords.words('english')]
            # print("Text without stop words:", " ".join(tokens_wo_stopwords))
            print(" ".join(tokens_wo_stopwords))
            for word in tokens_wo_stopwords:
                f.write(word)
                f.write(" ")
            f.write('\n')
