import sys

print(sys.version)

import json
from fastapi import FastAPI
#from fastapi.middleware.cors import CORSMiddleware

#from pydantic import BaseModel

from preprocess import prepro
from model_top2vec import top2vec_model

from top2vec import Top2Vec as tv


# 1. Define an API object
app = FastAPI(
    title='NLP',
    description='Designed for the Wellington Residence Survey'
)




###### Environment
# 2. Define data type
class Msg(BaseModel):
    msg: str

# 3. Map HTTP method and path to python function

#Home Default page.
@app.get("/")
async def root():
    return {"message": " Welcome to the NLP API home page!"}


@app.get("/path")
async def function_demo_get():
    return {"message": "This is /path endpoint, use post request to transform text to uppercase"}


@app.post("/path")
async def function_demo_post(inp: Msg):
    return {"message": inp.msg.upper()}


@app.get("/path/{path_id}")
async def function_demo_get_path_id(path_id: int):
    return {"message": f"This is /path/{path_id} endpoint, use post request to retrieve result"}


# 4. Start the API application (on command line)
# uvicorn main:app --reload
